package br.edu.ifsp.spo.java.cards.itens;

/**
 * Enumeração que representa os valores das cartas do baralho.
 */
public enum Valor {
    AS, DOIS, TRES, QUATRO, CINCO, SEIS, SETE, OITO, NOVE, DEZ, DAMA, VALETE, REI
}
