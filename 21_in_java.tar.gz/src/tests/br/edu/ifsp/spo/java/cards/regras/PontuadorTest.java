package br.edu.ifsp.spo.java.cards.regras;

import static org.junit.jupiter.api.Assertions.*;

import br.edu.ifsp.spo.java.cards.itens.Valor;
import br.edu.ifsp.spo.java.cards.itens.Naipe;
import org.junit.jupiter.api.Test;
import java.util.Arrays;
import java.util.List;
import br.edu.ifsp.spo.java.cards.itens.Carta;
import br.edu.ifsp.spo.java.cards.itens.Pontuador;

public class PontuadorTest {

    // Método auxiliar para criar cartas com valor e naipe
    private Carta criarCarta(Valor valor, Naipe naipe) {
        return new Carta(naipe, valor); // Agora passando Naipe e Valor
    }

    // Teste 1: Verificar pontuação para cartas de valor simples (AS, 2-10)
    @Test
    public void testPontuacaoSimples() {
        Pontuador pontuador = new Pontuador();

        List<Carta> cartas = Arrays.asList(
                criarCarta(Valor.AS, Naipe.OUROS), criarCarta(Valor.DOIS, Naipe.COPAS),
                criarCarta(Valor.TRES, Naipe.ESPADAS), criarCarta(Valor.QUATRO, Naipe.PAUS),
                criarCarta(Valor.CINCO, Naipe.OUROS)
        );

        int pontuacao = pontuador.verificarPontuacao(cartas, 1); // Modo 1
        assertEquals(1 + 2 + 3 + 4 + 5, pontuacao);

        pontuacao = pontuador.verificarPontuacao(cartas, 2); // Modo 2
        assertEquals(1 + 2 + 3 + 4 + 5, pontuacao);
    }

    // Teste 2: Verificar pontuação para figuras (VALETE, DAMA, REI) em modo 1 e modo 2
    @Test
    public void testPontuacaoFiguras() {
        Pontuador pontuador = new Pontuador();

        List<Carta> cartasModo1 = Arrays.asList(
                criarCarta(Valor.VALETE, Naipe.OUROS),
                criarCarta(Valor.DAMA, Naipe.COPAS),
                criarCarta(Valor.REI, Naipe.ESPADAS)
        );

        int pontuacaoModo1 = pontuador.verificarPontuacao(cartasModo1, 1);
        // No modo 1, cada figura vale 10 pontos
        assertEquals(10 + 10 + 10, pontuacaoModo1);

        List<Carta> cartasModo2 = Arrays.asList(
                criarCarta(Valor.VALETE, Naipe.PAUS),
                criarCarta(Valor.DAMA, Naipe.OUROS),
                criarCarta(Valor.REI, Naipe.COPAS)
        );

        int pontuacaoModo2 = pontuador.verificarPontuacao(cartasModo2, 2);
        // No modo 2, cada figura vale 1 ponto
        assertEquals(1 + 1 + 1, pontuacaoModo2);
    }

    // Teste 3: Verificar uma mistura de cartas e modos diferentes
    @Test
    public void testPontuacaoMisturada() {
        Pontuador pontuador = new Pontuador();

        List<Carta> cartas = Arrays.asList(
                criarCarta(Valor.AS, Naipe.OUROS), criarCarta(Valor.DOIS, Naipe.COPAS),
                criarCarta(Valor.VALETE, Naipe.ESPADAS),
                criarCarta(Valor.DAMA, Naipe.PAUS), criarCarta(Valor.REI, Naipe.OUROS)
        );

        int pontuacaoModo1 = pontuador.verificarPontuacao(cartas, 1);
        // AS + 2 + 10 (VALETE) + 10 (DAMAS) + 10 (REI) = 33
        assertEquals(1 + 2 + 10 + 10 + 10, pontuacaoModo1);

        int pontuacaoModo2 = pontuador.verificarPontuacao(cartas, 2);
        // AS + 2 + 1 (VALETE) + 1 (DAMAS) + 1 (REI) = 5
        assertEquals(1 + 2 + 1 + 1 + 1, pontuacaoModo2);
    }

    // Teste 4: Verificar pontuação com lista vazia
    @Test
    public void testPontuacaoListaVazia() {
        Pontuador pontuador = new Pontuador();

        List<Carta> cartas = Arrays.asList(); // Lista vazia
        int pontuacao = pontuador.verificarPontuacao(cartas, 1);

        assertEquals(0, pontuacao); // Esperado 0, pois não há cartas
    }

    // Teste 5: Verificar pontuação com várias cartas do mesmo valor
    @Test
    public void testPontuacaoCartasRepetidas() {
        Pontuador pontuador = new Pontuador();

        List<Carta> cartas = Arrays.asList(
                criarCarta(Valor.AS, Naipe.OUROS),
                criarCarta(Valor.AS, Naipe.COPAS),
                criarCarta(Valor.AS, Naipe.ESPADAS)
        );

        int pontuacao = pontuador.verificarPontuacao(cartas, 1);
        // 1 (AS) + 1 (AS) + 1 (AS) = 3
        assertEquals(1 + 1 + 1, pontuacao);
    }
}
