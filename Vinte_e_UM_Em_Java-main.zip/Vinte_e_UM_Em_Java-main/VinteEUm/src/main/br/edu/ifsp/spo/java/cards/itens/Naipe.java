package br.edu.ifsp.spo.java.cards.itens;

/**
 * Enumeração que representa os naipes das cartas em um baralho tradicional.
 */
public enum Naipe {
    COPAS, OUROS, PAUS, ESPADAS
}
